# Gan 并行任务实现计划

## 1. 目标与版本边界

实现用户构思的并行任务：

```gan
task "1" highest
    print console "后台任务'\n"

task "2" lowest
    print console "到达后才启动"
```

第一版目标：

- `highest`：无论源码位于何处，程序入口开始时立即启动，不等待前面的 `delay` 或其他语句。
- `lowest`：只有控制流实际执行到任务声明处才启动。
- `normal`：作为默认优先级，同样在控制流到达声明处时启动。
- 并行任务真正并发运行，主线程的 `delay` 不阻塞后台任务。
- `exit` 是全局强制退出，立即终止整个进程及所有任务。
- 普通 `return`：
  - 在任务体中只结束当前任务。
  - 在主入口中等待所有已启动任务结束后再返回。
- 第一版不实现任务间共享变量读写，任务之间仅通过文件、终端输出或明确的全局字节缓冲区通信。

第一版明确限制：

- 任务只能定义在程序顶层，不能定义在 `entry`、函数、循环或条件块内部。
- 任务数量最多 64 个。
- 任务 ID 使用非空字符串，只允许 ASCII 字母、数字、`.`、`_` 和 `-`，长度不超过 63 字节。
- 一个程序中的任务 ID 必须唯一。
- 任务体不能直接创建窗口、创建输入框或调用窗口事件接口。
- 任务体拥有独立局部作用域，不能引用主入口中的局部变量。
- 暂不提供任务取消、恢复、优先级抢占、线程池或 OS 调度优先级设置；`highest/normal/lowest` 表示启动语义，不是操作系统实时优先级。

## 2. 语法与语义设计

### 2.1 任务声明

规范语法：

```gan
task "id" priority
    语句...
    语句...
```

优先级关键字：

```gan
highest
normal
lowest
```

省略优先级时默认：

```gan
normal
```

任务体必须使用缩进块，至少缩进一级；块内继续使用现有语句：

```gan
task "count" highest
    variable "n" integer "0"
    cycle until n>5
        variable n=n+1
        delay "100"ms
        print console "count='n'"\n
```

### 2.2 启动位置

编译器先扫描所有顶层任务，再生成入口：

- 所有 `highest` 任务在 `gan_main` 正式主体执行前启动。
- `normal` 和 `lowest` 任务在原任务声明位置启动。
- 同一源码位置的多个任务按源码顺序调用创建接口。
- `highest` 即使写在文件末尾，也会在主程序第一条业务语句前启动。
- `lowest` 前面的 `delay` 会阻塞主线程，但不会阻止已经启动的 `highest` 后台任务。

### 2.3 退出语义

- 任务体中的 `return 表达式` 只返回该任务函数。
- 主入口中的 `return` 或隐式末尾 `return 0` 会等待所有已启动任务完成。
- 任意线程中的 `exit` 继续调用现有 `gan_exit`，立即终止整个进程。
- `!exit` 仍只跳出当前循环，不终止任务或程序。
- 任务创建失败时打印诊断并调用 `gan_panic`。

## 3. 运行时架构

### 3.1 使用 macOS pthread

在 `src/assembly/gancore.S` 增加任务运行时，使用 libSystem 的 pthread：

```text
pthread_mutex_init
pthread_mutex_lock
pthread_mutex_unlock
pthread_create
pthread_join
```

不使用新增宿主语言运行时，也不改变现有 clang + Mach-O 后端。

### 3.2 新增导出接口

计划导出：

```text
_gan_runtime_init
_gan_io_lock
_gan_io_unlock
_gan_task_create
_gan_task_wait_all
_gan_task_count
```

接口契约：

```c
intptr_t gan_task_create(intptr_t id, intptr_t priority, intptr_t body);
void gan_task_wait_all(void);
intptr_t gan_task_count(void);
void gan_runtime_init(void);
```

### 3.3 固定任务注册表

不依赖动态内存，在 `gancore.S` 数据段保留固定表：

```text
64 个任务槽
每槽：pthread_t 存储 + 状态 + 任务 ID 指针
状态：空闲 / 已创建 / 已结束
```

所有任务槽访问由运行时互斥锁保护。`gan_task_wait_all` 先复制待连接句柄，再在锁外执行 `pthread_join`，避免等待期间阻塞其他任务创建。

### 3.4 启动与初始化

现有 `gancore.S` 的 `_main` 调用 `_gan_main` 前先调用 `_gan_runtime_init`：

```text
_main
  → gan_runtime_init
  → gan_main
```

初始化：

- 递归 I/O 互斥锁。
- 64 个任务槽清零。
- 当前任务计数。

由于 `gancore.S` 已有 `_main` 强符号，该初始化不会破坏当前弱 `_gan_main` 覆盖机制。

### 3.5 I/O 串行化

新增递归互斥封装：

```text
gan_io_lock
gan_io_unlock
```

`gan_write_all` 对底层 `write` 加锁，保证单次数据块不被截断。

前端进一步为整个语句生成锁范围：

```text
print console ...
    gan_io_lock
    多个 gan1_print_* 调用
    gan_io_unlock

write </path> ...
    gan_io_lock
    create/open 和全部 write
    gan_io_unlock
```

递归锁允许语句级锁内的 `gan_write_all` 再次加锁。

### 3.6 主线程保护

窗口接口继续要求主线程。现有 `Lgan_gui_init` 已使用 `_pthread_main_np`，任务体中的窗口语句应在前端阶段直接报错：

```text
ganbuild: window statements are not allowed inside parallel tasks
```

对运行时直接调用窗口接口的情况，保持返回现有主线程错误，不自动切换到主线程。

## 4. C 中间代码生成

### 4.1 任务函数命名

任务 ID 可以是字符串 `"1"`，不能直接作为 C 标识符。前端为任务分配编译期序号：

```text
task "1" → gan_task_body_0
task "2" → gan_task_body_1
```

任务 ID 字符串仅用于错误诊断和运行时记录。

### 4.2 生成函数

每个任务生成一个 Gan 函数体和一个 pthread 入口包装：

```c
intptr_t module_task_body_0(void);

void *module_task_entry_0(void *context) {
    module_task_body_0();
    return 0;
}
```

任务声明编译为：

```c
if (gan_task_create(
    (intptr_t)"1",
    gan_priority_highest,
    (intptr_t)module_task_entry_0
) < 0) {
    gan_panic((intptr_t)"task creation failed");
}
```

优先级数值：

```text
lowest   = 0
normal   = 1
highest  = 2
```

### 4.3 入口生成

扫描阶段把 `highest` 任务收集成单独表。入口函数生成顺序改为：

```c
int gan_main(...) {
    /* highest task create calls */
    /* original entry body */
    /* implicit or explicit return */
    gan_task_wait_all();
    return status;
}
```

任务体中的 `return` 编译为任务函数返回，不能生成：

```c
gan_task_wait_all();
return ...;
```

### 4.4 主入口 return 改造

当前入口 `return` 直接生成 `return`。新规则：

```text
任务函数 return → 普通 return
主入口 return → gan_task_wait_all(); return value;
主入口隐式末尾 return → gan_task_wait_all(); return 0;
```

已有显式 `exit` 不插入 `gan_task_wait_all`，保持立即终止。

## 5. 原生前端修改

主要修改 `src/build/ganfrontend.gan`。

### 5.1 顶层扫描

在现有 `scan_prototypes` 附近增加任务收集：

- 识别 `task "`。
- 解析 ID 字符串和优先级关键字。
- 校验字符、长度、唯一性和缩进块存在。
- 保存任务 ID、优先级、任务体首行、块范围和编译序号。
- `highest` 标记入口 prologue 启动；其他标记源码位置启动。

### 5.2 任务块解析

复用现有 `child_indent` 与 `parse_block`：

- 任务声明行不进入隐式主入口语句集合。
- 任务体作为独立函数块生成。
- 递归处理块中的 `task` 并报错：`parallel tasks are only allowed at top level`。
- 遇到窗口语句时调用独立检查，禁止任务体内直接窗口语法。
- 设置当前上下文为 task，使 `return` 只返回任务函数。

### 5.3 作用域检查

第一版为任务体建立局部变量集合：

- 块内声明的变量只能在该任务中使用。
- 主入口或函数局部变量不能从任务体访问。
- 未声明标识符在生成 C 前报告：
  ```text
  ganbuild: unknown variable in parallel task
  ```

现有函数体也复用同一局部变量检查，减少未声明标识符延迟到 clang 的情况。

### 5.4 C 前导和原语

`emit_preamble` 增加：

```c
intptr_t gan_runtime_init(void);
void gan_io_lock(void);
void gan_io_unlock(void);
intptr_t gan_task_create(intptr_t,intptr_t,intptr_t);
void gan_task_wait_all(void);
```

任务体和入口代码使用这些声明。

## 6. helper 与完整 Gan 支持

`src/build/ganbuildhelper.gan` 不需要新增复杂翻译，但必须：

- 规范化 UTF-8 注释、零宽字符和全角标点。
- 保留 `task` 声明及缩进块。
- 确保 `highest` 任务在注入 `import "gan1"` 后仍保持顶层结构。
- 对 `//task "1" highest` 这类旧构思注释不做特殊解释；实现后用户需去掉 `//` 才能真正启用任务。

## 7. 自举顺序

必须按以下顺序推进，保持原生前端自举契约：

1. 汇编运行时先提供任务接口，但不修改前端。
2. 更新 `src/build/ganfrontend.gan` 支持 `task`。
3. 用现有 `build/ganfrontend` 种子编译一次新前端，生成临时种子。
4. 用新临时种子再次编译自身，比较两代 C 输出逐字节一致。
5. 用新种子重建正式 `build/ganfrontend`。
6. 重建 `ganbuildhelper.gan`。
7. 运行并行任务回归。
8. 重新运行原有控制台、GUI、文件、原生 `.S` 和诊断测试。

## 8. 测试设计

### 8.1 highest 立即运行

源码：

```gan
delay "1"s
print console "main-start"\n

task "bg" highest
    delay "100"ms
    print console "bg-start"
```

预期：

```text
bg-start
main-start
```

证明主线程延时不能阻止最高优先级任务。

### 8.2 lowest 到达后才运行

```gan
print console "before"
task "late" lowest
    print console "late"
delay "200"ms
print console "after-reach"
```

预期 `late` 不能出现在 `before` 之前；只有控制流到达声明处后才启动。

### 8.3 退出语义

- 主入口普通返回时等待任务。
- 任务调用 `return` 后主程序继续。
- 主或任务调用 `exit 1` 时整个进程立即终止。
- 主入口最终退出码保持不变。

### 8.4 诊断测试

必须覆盖：

- 重复任务 ID。
- 空任务 ID。
- 非法优先级。
- 任务块缺少缩进内容。
- 循环内定义任务。
- 任务体内创建窗口。
- 任务体引用外部局部变量。
- 超过 64 个任务。

### 8.5 并发输出和文件

- 两个任务连续写同一输出，验证单次语句不会字节交错。
- 两个任务写不同文件，验证互不阻塞。
- GUI 回归继续由主线程运行，任务不得访问窗口接口。

## 9. 文档更新

更新 `docs/gancore.md`：

- 组件图增加任务运行时。
- 新增 `3.6 并行任务`。
- 说明 `highest/normal/lowest` 的真实含义。
- 更新 `gancore.S` 接口表。
- 增加退出、等待、任务限制和线程安全说明。
- 在验证结果中加入任务样例。

## 10. 后续版本

第一版验证后，再分别规划：

- 顶层共享变量和原子读写。
- `wait task "id"`。
- `wait all` 显式语法。
- 主线程 UI 调度队列，允许任务安全提交窗口操作。
- OS 线程 QoS 映射。
- 任务取消和超时。
```