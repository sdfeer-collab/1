# Gan 纯原生汇编模块与构建链说明

## 1. 组件与职责

本项目面向 **macOS arm64**。语言实现、构建驱动和运行时只使用 Gan 与汇编：

```text
src/assembly​​/gancore.S       系统入口、核心运行时、pthread 和 AppKit 接口
src/assembly​​/ganbuild.S      构建驱动、系统调用接口和源码规范化
src/build/ganfrontend.gan    Gan 编写的原生前端，直接生成 arm64 汇编
build/ganfrontend           由自身汇编产物重建的原生自举种子
src/build/ganbuildhelper.gan 完整 Gan 到规范子集的翻译器
src/core/gan1.gan            打印、文件、窗口和输入导出库
```

普通程序的流水线为：

```text
完整 .gan
  → build/ganbuildhelper 规范化并注入 import "gan1"
  → 规范子集 .gan
  → build/ganbuild
  → build/ganfrontend 展开导入并生成 <output>.s
  → /usr/bin/clang 仅汇编为 <output>.o
  → /usr/bin/clang 链接 <output>.o、gancore.o、ganbuild.o 和系统 framework
  → Mach-O 可执行文件
```

`ganbuildhelper.gan` 只负责翻译，不接管最终编译。`ganbuild.S` 通过 `fork/execve/wait4` 依次驱动原生前端、汇编器和链接器。前端生成的强 `_gan_main` 覆盖 `gancore.S` 中的弱占位入口。

构建只使用 macOS 已有的 `/usr/bin/clang` 作为汇编器和链接驱动，不调用其宿主语言前端，也不需要包管理器、脚本运行时、第三方编译器或额外动态库。最终程序只依赖 macOS 系统库与 framework。

## 2. 构建与运行

### 2.1 构建运行时和构建器

在项目根目录执行：

```sh
/usr/bin/clang -arch arm64 -x assembler -c 'src/assembly​​/gancore.S' -o build/gancore.o
/usr/bin/clang -arch arm64 -x assembler -c 'src/assembly​​/ganbuild.S' -o build/ganbuild.o
/usr/bin/clang -arch arm64 -x none build/ganbuild.o -o build/ganbuild
```

### 2.2 重建前端、helper 和 gan1

```sh
./build/ganbuild src/build/ganfrontend.gan build/ganfrontend
./build/ganbuild
./build/ganbuild src/core/gan1.gan build/gan1
```

第二条命令等价于：

```sh
./build/ganbuild src/build/ganbuildhelper.gan build/ganbuildhelper
```

每次 `.gan` 构建都会保留 `<output>.s` 和 `<output>.o`。普通程序还会生成 `<output>` Mach-O 可执行文件。`src/core/gan1.gan` 是无入口库，所以第三条命令只生成 `build/gan1.s` 和 `build/gan1.o`，不执行程序链接。

普通程序通过 `import "gan1"` 将库源码并入当前生成单元，不再重复链接 `build/gan1.o`。除 `src/core/gan1.gan` 外，缺少入口的 `.gan` 会明确报错，不会静默运行弱占位程序。

### 2.3 翻译并构建 exp.gan

```sh
./build/ganbuildhelper exp.gan build/exp.subset.gan
./build/ganbuild build/exp.subset.gan build/exp
./build/exp
```

helper 支持自定义输入输出参数；省略时默认为 `exp.gan` 和 `build/exp.subset.gan`。完整示例创建窗口并执行延时循环，最后通过 `exit 1` 的附带块打印 `bye`，以状态 1 退出。

直接构建不含 `import "gan1"` 的完整 Gan 测试时，也必须先经过 helper；规范子集才可直接交给 `ganbuild`。

### 2.4 原生汇编输入

```sh
./build/ganbuild 'src/assembly​​/gancore.S' build/gancore
./build/gancore
```

预期输出：

```text
gancore: ok
```

显式 `.S/.s` 输入直接由系统 clang 汇编和链接，并附加 AppKit 与 Foundation。其他扩展名返回 `-ENOSYS`，命令行显示 `ganbuild: unsupported source format`。

### 2.5 原生前端自举

正式种子已经由自身生成的汇编重建。需要重复验证时，可执行两代构建并比较输出：

```sh
./build/ganbuild src/build/ganfrontend.gan build/ganfrontend.gen1
./build/ganfrontend.gen1 src/build/ganfrontend.gan build/ganfrontend.gen2.s
/usr/bin/clang -arch arm64 -x assembler build/ganfrontend.gen2.s -c -o build/ganfrontend.gen2.o
/usr/bin/clang -arch arm64 -x none build/ganfrontend.gen2.o build/gancore.o build/ganbuild.o -framework AppKit -framework Foundation -o build/ganfrontend.gen2
cmp build/ganfrontend.gen1.s build/ganfrontend.gen2.s
```

`cmp` 无输出且返回 0，表示连续两代汇编逐字节一致。通过比较后，第二代种子可用于替换 `build/ganfrontend`。日常构建不执行任何旧迁移种子。

## 3. Gan 子集语法

### 3.1 模块和入口

```gan
module "example"
import "gan1"

entry
    print console "hello"\n
    return 0
```

- `module` 决定普通函数的符号前缀，例如模块 `gan1` 中的 `print_string` 导出为 `_gan1_print_string`。
- `import "gan1"` 引入 `src/core/gan1.gan`。
- `entry` 定义显式程序入口；顶层业务语句也会形成隐式入口。
- 一个程序只能有一个入口，入口导出 `_gan_main`。
- `arg(index)` 从主入口保存的 `argv` 读取参数，例如 `arg(1)`。

### 3.2 函数、变量和表达式

```gan
export func "twice"(value)
    return value*2

variable "a" integer "-10"
variable "name" string "Gan"
variable "buffer" bytes "1024"
variable a=a+1
variable result=twice(a)
call print_string("done")
```

- 参数和值统一使用 64 位寄存器表示，函数支持 0 到 8 个参数。
- `integer`、`string`、`bytes` 分别声明整数、字符串指针和零初始化字节数组。
- 支持整数、字符串、变量、函数调用、括号、一元 `+ - ! not`、`+ - * / %`、有符号比较以及 `and/or` 短路逻辑。
- `getbyte(address)` 和 `setbyte(address,value)` 直接生成字节加载与存储。
- `return` 未带表达式时返回 0。
- 为兼容 `exp.gan`，`varibale` 暂时作为 `variable` 的别名。

### 3.3 打印、延时和文件

```gan
print console "hello"\n"值='a'"
delay "45"s
delay "299"ms
create </aaaaa.txt>
write </aaaaa.txt> "这是个代码"\n
```

- `\n` 和 `/n` 都表示换行。
- 字符串中的 `'a'` 表示插入变量 `a` 的整数值。
- `delay` 支持 `s` 和 `ms`，最终调用 `gan_sleep`。
- `create` 使用 `O_WRONLY|O_CREAT|O_TRUNC` 创建或截断文件。
- `write` 先创建目标文件，再以追加方式写入各段内容。
- 整个打印或文件写语句由递归 I/O 互斥锁串行化，避免并行任务的语句内字节交错。

### 3.4 条件、循环和退出

```gan
cycle until a>3
    variable a=a+1
    !exit print console "完成"/n"你好'a'"
        variable a=1
        varibale a-1

exit 1
    print console "bye"
```

- `cycle until condition` 在条件为真时停止，否则执行缩进块。
- `if condition` 和 `if input` 使用缩进块，暂不支持 `else`。
- `!exit statement` 执行该语句及其缩进附带块，然后跳出当前循环。
- `exit status` 先执行缩进附带块，再立即终止整个进程，不等待并行任务。
- 缩进使用空格，不允许使用 Tab。

### 3.5 并行任务

```gan
task "logger" highest
    print console "started"\n
    return 0

task "writer" normal
    write </task.txt> "done"\n

task "later" lowest
    print console "later"\n
```

任务声明规则：

- 语法为 `task "id" [highest|normal|lowest]`，省略优先级时为 `normal`。
- 每个程序最多 64 个任务；ID 必须唯一、非空、最长 63 字节，只允许 ASCII 字母、数字、`.`、`_`、`-`。
- 任务只能位于顶层，必须具有缩进任务体。ID 只作为运行时数据，不拼入汇编符号。
- 任务拥有独立局部帧，不能引用主入口、函数或其他任务的局部变量。
- 任务内禁止 `create window`、`window ... create` 和 `if input`；AppKit 操作继续限制在主线程。

启动与退出语义：

- 所有 `highest` 在主入口业务语句前启动。
- `normal/lowest` 在顶层源码声明位置启动；同一位置按源码顺序调用 `pthread_create`，但不改变 OS 调度优先级。
- 显式 `entry` 之前的非 `highest` 任务在入口主体前启动，之后的任务在入口主体自然结束后启动。
- 主入口正常结束或显式 `return` 时等待全部已启动任务；任务的 `return` 只结束当前任务。
- 主入口或任务中的 `exit` 都立即终止整个进程，不执行任务等待。
- 任务创建失败会进入 `gan_panic`。

### 3.6 窗口和即时输入

```gan
create window "aaa" "110*123" [#000000]
window "aaa" create "01" "10,1" "100,111" [#CECECB]
if input "aaa" "01" "123"
    exit 0
```

- `create window` 创建指定标题、像素尺寸和 RGB 背景色的 `NSWindow`。
- `window ... create` 创建可编辑 `NSTextField`；位置和尺寸格式分别为 `x,y` 与 `width,height`。
- 输入变化通过 `NSControlTextDidChangeNotification` 即时记录。
- `if input` 查询是否曾出现过目标文本，不只比较当前文本。
- `gan1_input_set` 提供程序化输入，也用于自动化验证。
- 当前运行时为单窗口、单输入框实现，输入历史上限为 4096 字节；窗口接口必须在主线程调用。

## 4. 原生汇编后端与 ABI

- 代码写入 `__TEXT,__text`，字符串写入 `__TEXT,__cstring`，必要可变状态写入 BSS，并输出 `.subsections_via_symbols`。
- 表达式采用栈式求值，结果统一放入 `x0`；中间值按 16 字节对齐压栈。
- 函数参数使用 `x0-x7`，返回值使用 `x0`，函数保存 `x29/x30`，所有调用点保持 `sp` 16 字节对齐。
- 局部符号在生成汇编前解析，参数、`integer/string/bytes` 都有明确的相对 `x29` 帧偏移。
- 任意帧大小和大偏移通过 `movz/movk` 序列处理；大帧按 4096 字节页触栈，前端的 7 MB 上下文不会跳过栈保护页。
- 普通函数、入口和任务使用唯一汇编标签与统一返回出口。
- `print/create/write/delay/window/if input` 直接调用 `_gan1_*` 和 `_gan_*` 汇编接口。
- 每个任务生成 `_gan_task_body_N` 与 `_gan_task_entry_N`，pthread 包装返回空指针。

## 5. 对外接口

### 5.1 gancore.S

| 接口 | 行为 |
| --- | --- |
| `_main` | 初始化运行时并调用 `_gan_main` |
| `_gan_main` | 弱占位 Gan 入口，可被生成代码的强符号覆盖 |
| `_gan_strlen` | 返回 NUL 结尾字符串的字节长度 |
| `_gan_memcpy` / `_gan_memmove` | 支持重叠区域的内存复制 |
| `_gan_memset` | 使用 `value & 0xff` 填充内存 |
| `_gan_memcmp` | 比较无符号字节序列 |
| `_gan_read` / `_gan_write` | Darwin 读写，失败返回负 errno |
| `_gan_exit` / `_gan_panic` | 终止程序；panic 向 stderr 写消息和换行 |
| `_gan_sleep` | 毫秒延时，使用 libSystem `nanosleep`，失败返回负 errno |
| `_gan_runtime_init` | 初始化递归 I/O 互斥锁 |
| `_gan_io_lock` / `_gan_io_unlock` | 串行化完整 I/O 语句和任务表操作 |
| `_gan_task_create` | 在固定 64 项任务表中创建并登记 pthread |
| `_gan_task_wait_all` | 连接全部已创建任务，不在 join 期间持有互斥锁 |
| `_gan_task_count` | 返回尚未连接的任务数 |
| `_gan_window_create` | 创建 AppKit 窗口 |
| `_gan_window_input_create` | 创建输入框并注册即时变化通知 |
| `_gan_window_input_seen` | 推进事件循环并查询输入历史 |
| `_gan_window_input_set` | 设置输入文本并记录变化 |

### 5.2 ganbuild.S

| 接口 | 行为 |
| --- | --- |
| `_gan_build` | 设置默认 helper 路径并进入构建 |
| `_gan_compile_subset` | 分派 `.gan` 或原生 `.S/.s` 构建 |
| `_gan_compile_frontend` | 生成 `<output>.s`，仅汇编为 `<output>.o`，再按需要链接 |
| `_gan_normalize` | 去除注释和零宽字符，统一全角引号和逗号 |
| `_gan_open` / `_gan_close` / `_gan_lseek` / `_gan_fsync` | 文件和描述符操作 |
| `_gan_access` / `_gan_chdir` / `_gan_readlink` | 路径和目录操作 |
| `_gan_dup` / `_gan_dup2` / `_gan_pipe` | 描述符复制和管道 |
| `_gan_fork` / `_gan_getpid` / `_gan_getppid` | 进程接口 |
| `_gan_read_all` / `_gan_write_all` | 处理部分读写，直到完成、EOF 或错误 |

### 5.3 gan1.gan

当前导出：

```text
_gan1_print_string
_gan1_print_integer
_gan1_create
_gan1_write
_gan1_window_create
_gan1_input_create
_gan1_input_seen
_gan1_input_set
```

可使用以下命令检查：

```sh
nm -m build/gan1.o | grep 'external _gan1_'
nm -m build/gancore.o | grep '_gan_main'
nm -m build/exp | grep '_gan_main'
otool -L build/exp
```

`gancore.o` 中应显示 `weak external _gan_main`，最终程序中应显示普通 `external _gan_main`。`gan1.o` 应包含上述 8 个导出符号，`otool -L` 只应列出 macOS 系统库和 framework。

## 6. 错误与 ABI 约定

- 原始 Darwin 系统调用失败时返回 `-errno`，不设置 libc `errno`。
- `gan_sleep` 通过 libSystem 调用，失败时读取 `__error()` 并返回负 errno。
- 单次 `gan_read` 或 `gan_write` 可能只处理部分数据；完整读写接口会循环处理。
- `gan_write_all` 遇到零进展写入时返回已写字节数，避免死循环。
- 构建器返回前端、汇编器或链接器退出码、`128+signal` 或负 errno；命令行将负错误映射为退出码 1。
- 参数过多时构建器返回 64；缺少入口、非法表达式、错误缩进和未定义符号会明确报错。
- 非顶层任务、重复或非法 ID、非法优先级、缺少任务体、超过 64 个任务、外部局部变量引用和任务内窗口语句均在生成汇编前报错。
- 所有函数遵守 macOS arm64 ABI 和 16 字节栈对齐。
- Objective-C 对象和颜色等跨调用参数必须保存在被调用者保存寄存器中，不能依赖调用者保存的 `x2` 在获取 selector 后保持不变。
- `ganbuild.S` 的 `_main` 是弱符号，因此生成程序可以同时链接 `gancore.o` 与 `ganbuild.o`，并选用 `gancore.S` 的强 `_main`。
- Darwin 原始 `fork` 使用 `x1=1` 识别子进程，父进程分支为 `x1=0`；`_gan_fork` 封装在子进程中按约定返回 0。原始 `pipe` 通过 `x0/x1` 返回两个描述符。

## 7. 已验证结果

当前纯 Gan/汇编实现已通过以下回归：

1. 原生前端连续两代自身汇编逐字节一致，正式种子由第二代产物重建；再次重建仍保持一致。
2. `ganbuildhelper.gan`、`src/core/gan1.gan` 和全部示例均通过 `.gan → .s → .o → Mach-O` 流水线重建。
3. 表达式、0/1/8 参数调用、递归、字符串转义、短路逻辑、循环跳出、5000 字节局部帧和文件写测试通过；前端自身的 7 MB 帧自举通过。
4. `highest` 在主延时期间运行，`normal/lowest` 在声明位置运行，显式入口前后任务以及主入口等待语义通过。
5. 64 个任务成功构建运行，65 个任务及全部任务声明诊断路径通过；主入口和任务中的全局 `exit` 分别验证为状态 6 和 7。
6. 两个并行任务各输出 20 条定长语句，没有语句内字节交错；两个不同输出文件内容完整。
7. 纯汇编 pthread 运行时测试验证任务创建、计数、等待和清零。
8. 完整 `exp.gan` 实际运行并以状态 1 退出，输出为：

```text
hello
hello完成
你好-9bye
```

9. 控制台测试保持退出码和文件行为；GUI 测试创建真实窗口和输入框，依次设置 `123`、`456` 后，历史查询 `123` 返回 1。
10. 原生 `.S` 构建、缺少入口、非法表达式、不支持扩展名和参数过多诊断通过。
11. `nm -m` 验证入口强弱覆盖和 8 个 `gan1` 导出；`otool -L` 只显示 macOS 系统库与 framework。
12. 全仓没有宿主语言实现、测试或生成物，也没有宿主头文件和对应语言编译参数。
